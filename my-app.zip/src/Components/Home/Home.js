import React, { Component } from 'react'
import Footer from '../Footer/Footer'
import Navbar from '../Navbar/Navbar'
import './Home.css'

export class Home extends Component {
    render() {
        return (
            <div>
                <Navbar/>
                <div className='body' style={{backgroundImage: `url(/Images/logo.svg)` }}>
                        <h1 className='logo-text'>React</h1>
                        <h2>A JavaScript library for building user interfaces</h2>
                        <div className='side-by-side'>
                            <button>Get Started</button>
                            <a href="" className='link'>Take the tutorials <i class="fas fa-angle-right "></i></a>
                        </div>
                </div>
                <div>
                    <div className='content'>
                        <div className='content1'>
                            <h3>Declarative</h3>
                            <p className='p-style'>React makes it painless to create interactive UIs. Design simple views for each state in your application, and React will efficiently update and render just the right components when your data changes.</p>
                            <p className="p-style">Declarative views make your code more predictable and easier to debug.</p>
                        </div>
                        <div className='content1'>
                         <h3>Component-Based</h3>
                         <p className='p-style'>Build encapsulated components that manage their own state, then compose them to make complex UIs.</p>
                        <p className="p-style">Since component logic is written in JavaScript instead of templates, you can easily pass rich data through your app and keep state out of the DOM.</p>
                        </div>
                        <div className='content1'>
                            <h3>Learn Once, Write Anywhere</h3>
                            <p className='p-style'>We don’t make assumptions about the rest of your technology stack, so you can develop new features in React without rewriting existing code.</p>
                            <p className="p-style">React can also render on the server using Node and power mobile apps using React Native.</p>
                        </div>
                    </div>
                </div>
                <div>
                  
                </div>
                <Footer/>
            </div>
        )
    }
}

export default Home
