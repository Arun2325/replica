export const MenuItems = [
    {
        tittle: 'Tv Shows',
        url: 'tvshows'
    },
    {
        tittle: 'Originals',
        url: 'originals'
    },
    {
        tittle: 'Sports',
        url : 'sports'
    },
    {
        tittle: 'Movie',
        url : 'movie'
    },
    {
        tittle: 'Premium',
        url : 'premium'
    },
    {
        tittle:'Games',
        url : 'games'
    }
]